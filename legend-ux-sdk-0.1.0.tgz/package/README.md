# @legend/ux-sdk

설치형 브라우저 SDK 패키지입니다.

## 설치

```bash
npm install @legend/ux-sdk
```

## 사용

```js
import UXSDK from "@legend/ux-sdk";

UXSDK.initUxSdk({
  siteId: "legend-ecommerce",
  sdkBaseUrl: "http://localhost:3001"
});
```

또는

```js
import { initUxSdk } from "@legend/ux-sdk";

initUxSdk({
  siteId: "legend-ecommerce",
  sdkBaseUrl: "http://localhost:3001"
});
```

dashboard/editor는 이 패키지에 포함되지 않으며 별도 대시보드 서비스에서 호스팅됩니다.

브라우저 `<script>` 방식으로 사용할 때 전역 이름은 `MiniSDK`입니다.
